"""Classical baselines. All take normalized [0,1] cubes (H, W, B) and
return (reconstruction, total_bits)."""
import io
import numpy as np
from PIL import Image
from scipy.fft import dct, idct, dctn, idctn
from sklearn.decomposition import PCA
from common.metrics import quantize


# ---------- spectral transforms + uniform quantization ----------

def pca_codec(train, test, k, bits=8):
    """PCA basis learned on TRAIN region, applied to TEST."""
    B = test.shape[-1]
    pca = PCA(k).fit(train.reshape(-1, B))
    z = pca.transform(test.reshape(-1, B))
    zq, nbits = quantize(z, bits)
    rec = pca.inverse_transform(zq.numpy()).reshape(test.shape)
    return np.clip(rec, 0, 1), nbits


def dct_codec(train, test, k, bits=8):
    """Spectral 1D DCT + zonal coding: keep the k DCT coefficients with the
    highest energy on the TRAIN region, 8-bit quantize them."""
    B = test.shape[-1]
    energy = (dct(train.reshape(-1, B), norm="ortho", axis=1) ** 2).mean(0)
    keep = np.argsort(-energy)[:k]
    c = dct(test.reshape(-1, B), norm="ortho", axis=1)[:, keep]
    cq, nbits = quantize(c, bits)
    full = np.zeros((c.shape[0], B), np.float32)
    full[:, keep] = cq.numpy()
    rec = idct(full, norm="ortho", axis=1).reshape(test.shape)
    return np.clip(rec, 0, 1), nbits


def _entropy_bits(q):
    """Zero-order entropy, one adaptive model per coefficient position
    (an estimate of what an arithmetic coder would spend)."""
    total = 0.0
    for pos in range(q.shape[1]):
        _, cnt = np.unique(q[:, pos], return_counts=True)
        total += -(cnt * np.log2(cnt / cnt.sum())).sum()
    return total


def dct3d_codec(test, step, b=8):
    """JPEG-style 3D DCT on 8x8x8 blocks, uniform quantization with
    step size `step`, rate = entropy estimate of the quantized coefficients."""
    H, W, B = test.shape
    Hp, Wp = -(-H // b) * b, -(-W // b) * b
    x = np.pad(test, ((0, Hp - H), (0, Wp - W), (0, 0)), mode="edge")
    blk = (x.reshape(Hp//b, b, Wp//b, b, B//b, b)
            .transpose(0, 2, 4, 1, 3, 5).reshape(-1, b, b, b))
    q = np.round(dctn(blk, axes=(1, 2, 3), norm="ortho") / step)
    bits = _entropy_bits(q.reshape(len(q), -1))
    R = idctn(q * step, axes=(1, 2, 3), norm="ortho")
    R = (R.reshape(Hp//b, Wp//b, B//b, b, b, b)
          .transpose(0, 3, 1, 4, 2, 5).reshape(Hp, Wp, B)[:H, :W])
    return np.clip(R, 0, 1), bits


# ---------- image codecs ----------
# Bands are tiled into ONE mosaic image so the file header is paid once,
# not 200 times (otherwise header overhead dominates at these small sizes).

def _mosaic(cube, cols):
    H, W, B = cube.shape
    rows = int(np.ceil(B / cols))
    m = np.zeros((rows * H, cols * W), cube.dtype)
    for b in range(B):
        r, c = divmod(b, cols)
        m[r*H:(r+1)*H, c*W:(c+1)*W] = cube[:, :, b]
    return m

def _unmosaic(m, shape, cols):
    H, W, B = shape
    out = np.zeros(shape, np.float32)
    for b in range(B):
        r, c = divmod(b, cols)
        out[:, :, b] = m[r*H:(r+1)*H, c*W:(c+1)*W]
    return out


def jpeg_codec(test, quality, cols=20):
    """Baseline JPEG (8-bit) on a mosaic of all bands."""
    m = _mosaic(np.round(np.clip(test, 0, 1) * 255).astype(np.uint8), cols)
    buf = io.BytesIO()
    Image.fromarray(m).save(buf, "JPEG", quality=quality)
    dec = np.array(Image.open(io.BytesIO(buf.getvalue())), np.float32) / 255
    return _unmosaic(dec, test.shape, cols), len(buf.getvalue()) * 8


def _j2k(img16, ratio):
    buf = io.BytesIO()
    Image.fromarray(img16).save(buf, "JPEG2000", quality_mode="rates",
                                quality_layers=[ratio], irreversible=True)
    dec = np.array(Image.open(io.BytesIO(buf.getvalue())), np.float32)
    return dec, len(buf.getvalue()) * 8


def jpeg2000_codec(test, target_bpppb, cols=20):
    """JPEG2000 (16-bit) on a mosaic of all bands."""
    m = _mosaic(np.round(np.clip(test, 0, 1) * 65535).astype(np.uint16), cols)
    dec, nbits = _j2k(m, 16 / target_bpppb)
    return _unmosaic(dec / 65535, test.shape, cols), nbits


def pca_jpeg2000_codec(train, test, k, target_bpppb):
    """Standard HSI pipeline: PCA across bands (basis from TRAIN),
    then JPEG2000 on the k principal-component images."""
    H, W, B = test.shape
    pca = PCA(k).fit(train.reshape(-1, B))
    z = pca.transform(test.reshape(-1, B)).reshape(H, W, k)
    lo, hi = z.min((0, 1)), z.max((0, 1))
    zn = (z - lo) / (hi - lo)
    m = _mosaic(np.round(zn * 65535).astype(np.uint16), cols=k)
    budget = target_bpppb * H * W * B
    dec, nbits = _j2k(m, (H * W * k * 16) / budget)
    zr = _unmosaic(dec / 65535, (H, W, k), cols=k) * (hi - lo) + lo
    rec = pca.inverse_transform(zr.reshape(-1, k)).reshape(test.shape)
    side = 2 * 32 * k
    return np.clip(rec, 0, 1), nbits + side
