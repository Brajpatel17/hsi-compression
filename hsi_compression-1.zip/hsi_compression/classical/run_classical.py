import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT); os.chdir(ROOT)   # run from anywhere
from common.data import load_split
from common.metrics import score
from common.logger import Logger
from classical.codecs import (pca_codec, dct_codec, dct3d_codec, jpeg_codec,
                                  jpeg2000_codec, pca_jpeg2000_codec)

train, test, _ = load_split()
L = Logger("classical", "classical")

def run(method, setting, out, save):
    rec, bits = out
    L.log(method, setting, score(test, rec, bits), rec if save else None)

for k in [2, 4, 8, 16, 32]:
    run("PCA", f"k={k}", pca_codec(train, test, k), k == 4)
for k in [4, 8, 16, 32, 64]:
    run("DCT", f"k={k}", dct_codec(train, test, k), k == 4)
for s in [0.3, 0.2, 0.15, 0.1, 0.05, 0.03, 0.02]:
    run("3D-DCT", f"step={s}", dct3d_codec(test, s), s == 0.15)
for q in [5, 10, 25, 50, 75, 90]:
    run("JPEG", f"q={q}", jpeg_codec(test, q), q == 10)
for b in [0.05, 0.1, 0.16, 0.2, 0.4, 0.8, 1.6]:
    run("JPEG2000", f"{b}bpppb", jpeg2000_codec(test, b), b == 0.16)
for b in [0.02, 0.05, 0.1, 0.16, 0.2, 0.4, 0.8]:
    run("PCA+JPEG2000", f"{b}bpppb", pca_jpeg2000_codec(train, test, 20, b), b == 0.16)
