import csv, os
import numpy as np

class Logger:
    """Collects rows, prints them, writes results/<name>.csv,
    saves one reconstruction per method for the visual figures."""
    def __init__(self, group, csv_name):
        """group = "classical" or "neural" -> results/<group>/<csv_name>.csv"""
        self.dir = f"results/{group}"
        self.path = f"{self.dir}/{csv_name}.csv"
        self.rows = []
        os.makedirs(f"{self.dir}/recon", exist_ok=True)

    def log(self, method, setting, r, rec=None):
        print(f"{method:14s} {setting:>10}  bpppb={r['bpppb']:.3f}  "
              f"PSNR={r['PSNR']:.2f} dB  SAM={r['SAM']:.2f} deg", flush=True)
        self.rows.append([method, setting, r["bpppb"], r["PSNR"], r["SAM"]])
        if rec is not None:
            np.save(f"{self.dir}/recon/{method}.npy", rec.astype(np.float16))
            with open(f"{self.dir}/recon/{method}.txt", "w") as f:
                f.write(f"{r['bpppb']:.4f}")
        self.write()

    def write(self):
        with open(self.path, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["method", "setting", "bpppb", "PSNR", "SAM"])
            w.writerows(self.rows)
