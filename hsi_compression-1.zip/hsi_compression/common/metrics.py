import numpy as np
import torch

def psnr(x, y, peak=1.0):
    return float(10 * np.log10(peak**2 / np.mean((x - y) ** 2)))

def sam(x, y, eps=1e-8):
    """Mean spectral angle in degrees; x, y shaped (..., bands)."""
    x = x.reshape(-1, x.shape[-1]).astype(np.float64)
    y = y.reshape(-1, y.shape[-1]).astype(np.float64)
    cos = (x * y).sum(1) / (np.linalg.norm(x, axis=1) * np.linalg.norm(y, axis=1) + eps)
    return float(np.degrees(np.arccos(np.clip(cos, -1, 1))).mean())

def quantize(z, bits=8, ch_dim=-1):
    """Uniform per-channel quantization of a latent tensor.
    Each channel gets its own min/max (stored as 2 float32 = side info).
    Returns (dequantized tensor, total bits incl. side info)."""
    z = torch.as_tensor(z, dtype=torch.float32)
    ch_dim = ch_dim % z.dim()
    dims = [d for d in range(z.dim()) if d != ch_dim]
    lo = z.amin(dim=dims, keepdim=True)
    hi = z.amax(dim=dims, keepdim=True)
    L = 2**bits - 1
    q = torch.round((z - lo) / (hi - lo + 1e-12) * L)
    side_bits = 2 * 32 * z.shape[ch_dim]
    return q / L * (hi - lo) + lo, z.numel() * bits + side_bits

def bpppb(total_bits, cube_shape):
    """Bits per pixel per band (original data is 16 bpppb)."""
    return float(total_bits / np.prod(cube_shape))

def score(orig, rec, total_bits):
    return {"bpppb": bpppb(total_bits, orig.shape),
            "PSNR": psnr(orig, rec), "SAM": sam(orig, rec)}
