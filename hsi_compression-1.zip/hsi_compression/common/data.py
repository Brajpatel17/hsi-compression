import json, os
import numpy as np

SPLIT_DIR = "data/split"

def load_split():
    """Loads the TRAIN / TEST regions made by split_data.py
    (already normalized to [0, 1] with train statistics)."""
    if not os.path.exists(f"{SPLIT_DIR}/train.npy"):
        raise FileNotFoundError("Run `python split_data.py` first.")
    train = np.load(f"{SPLIT_DIR}/train.npy")
    test = np.load(f"{SPLIT_DIR}/test.npy")
    with open(f"{SPLIT_DIR}/split_info.json") as f:
        info = json.load(f)
    return train, test, info
