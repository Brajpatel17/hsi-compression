import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT); os.chdir(ROOT)   # run from anywhere
import numpy as np, torch
from common.data import load_split
from neural.train import train_patch_model, evaluate_patch
from common.logger import Logger
from neural.models.cnn3d_ae import CNN3DAE

STEPS = int(sys.argv[1]) if len(sys.argv) > 1 else 1500
torch.manual_seed(0); np.random.seed(0)
train, test, _ = load_split()
L = Logger("neural", "cnn3d_ae")
for c in [1, 2, 3, 4]:
    print(f"Training 3D-CNN-AE c={c}")
    m = train_patch_model(CNN3DAE(c=c), train, steps=STEPS)
    r, rec = evaluate_patch(m, test)
    L.log("3D-CNN-AE", f"c={c}", r, rec if c == 3 else None)
