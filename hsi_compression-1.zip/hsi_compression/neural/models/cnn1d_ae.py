import torch.nn as nn

class CNN1DAE(nn.Module):
    """Model 2: per-pixel 1D-CNN autoencoder.
    Convolutions slide along the spectrum (neighbouring bands share filters),
    then a linear layer squeezes the features into a k-dim code."""
    def __init__(self, bands=200, k=16):
        super().__init__()
        self.enc = nn.Sequential(
            nn.Conv1d(1, 16, 7, stride=2, padding=3), nn.ReLU(),   # 200 -> 100
            nn.Conv1d(16, 32, 5, stride=2, padding=2), nn.ReLU(),  # 100 -> 50
            nn.Conv1d(32, 32, 5, stride=2, padding=2), nn.ReLU(),  # 50 -> 25
            nn.Flatten(), nn.Linear(32 * 25, k))
        self.dec_fc = nn.Sequential(nn.Linear(k, 32 * 25), nn.ReLU())
        self.dec = nn.Sequential(
            nn.ConvTranspose1d(32, 32, 4, stride=2, padding=1), nn.ReLU(),  # 25 -> 50
            nn.ConvTranspose1d(32, 16, 4, stride=2, padding=1), nn.ReLU(),  # 50 -> 100
            nn.ConvTranspose1d(16, 1, 4, stride=2, padding=1), nn.Sigmoid())  # 100 -> 200
    def encode(self, x):            # x: (N, 200)
        return self.enc(x.unsqueeze(1))
    def decode(self, z):            # z: (N, k)
        return self.dec(self.dec_fc(z).view(-1, 32, 25)).squeeze(1)
    def forward(self, x):
        return self.decode(self.encode(x))
