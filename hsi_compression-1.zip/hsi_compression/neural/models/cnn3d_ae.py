import torch.nn as nn

def block(cin, cout, k, s):
    pad = tuple(kk // 2 for kk in k)
    return nn.Sequential(nn.Conv3d(cin, cout, k, stride=s, padding=pad), nn.ReLU())

class CNN3DAE(nn.Module):
    """Model 3: fully convolutional 3D autoencoder on (bands, H, W) volumes.
    Uses spatial AND spectral redundancy. Downsamples bands x8, space x4,
    so the code is c x 25 x H/4 x W/4  ->  bpppb = c * 0.0625 at 8 bits.
    Input H, W must be multiples of 4."""
    def __init__(self, c=4):
        super().__init__()
        self.enc = nn.Sequential(
            block(1, 8, (7, 3, 3), (2, 1, 1)),    # D 200 -> 100
            block(8, 16, (5, 3, 3), (2, 2, 2)),   # D 100 -> 50,  H,W /2
            block(16, 16, (5, 3, 3), (2, 2, 2)),  # D 50 -> 25,   H,W /4
            nn.Conv3d(16, c, 1))
        self.dec = nn.Sequential(
            nn.Conv3d(c, 16, 1), nn.ReLU(),
            nn.Upsample(scale_factor=(2, 2, 2)), block(16, 16, (5, 3, 3), 1),
            nn.Upsample(scale_factor=(2, 2, 2)), block(16, 8, (5, 3, 3), 1),
            nn.Upsample(scale_factor=(2, 1, 1)),
            nn.Conv3d(8, 1, (7, 3, 3), padding=(3, 1, 1)), nn.Sigmoid())
    def encode(self, x):            # x: (N, 1, 200, H, W)
        return self.enc(x)
    def decode(self, z):
        return self.dec(z)
    def forward(self, x):
        return self.decode(self.encode(x))
