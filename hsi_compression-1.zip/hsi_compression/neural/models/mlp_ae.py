import torch.nn as nn

class MLPAE(nn.Module):
    """Model 1: per-pixel spectral MLP autoencoder."""
    def __init__(self, bands=200, k=16):
        super().__init__()
        self.enc = nn.Sequential(nn.Linear(bands, 128), nn.ReLU(),
                                 nn.Linear(128, 64), nn.ReLU(),
                                 nn.Linear(64, k))
        self.dec = nn.Sequential(nn.Linear(k, 64), nn.ReLU(),
                                 nn.Linear(64, 128), nn.ReLU(),
                                 nn.Linear(128, bands), nn.Sigmoid())
    def encode(self, x): return self.enc(x)
    def decode(self, z): return self.dec(z)
    def forward(self, x): return self.decode(self.encode(x))
