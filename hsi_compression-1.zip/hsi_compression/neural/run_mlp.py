import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT); os.chdir(ROOT)   # run from anywhere
import torch
from common.data import load_split
from neural.train import train_model, evaluate
from common.logger import Logger
from neural.models.mlp_ae import MLPAE

EPOCHS = int(sys.argv[1]) if len(sys.argv) > 1 else 400
torch.manual_seed(0)
train, test, _ = load_split()
L = Logger("neural", "mlp_ae")
for k in [4, 8, 16]:
    print(f"Training MLP-AE k={k}")
    m = train_model(MLPAE(k=k), train.reshape(-1, 200), epochs=EPOCHS)
    r, rec = evaluate(m, test)
    L.log("MLP-AE", f"k={k}", r, rec if k == 4 else None)
