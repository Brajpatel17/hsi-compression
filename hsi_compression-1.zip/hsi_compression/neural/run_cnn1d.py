import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT); os.chdir(ROOT)   # run from anywhere
import torch
from common.data import load_split
from neural.train import train_model, evaluate
from common.logger import Logger
from neural.models.cnn1d_ae import CNN1DAE

EPOCHS = int(sys.argv[1]) if len(sys.argv) > 1 else 300
torch.manual_seed(0)
train, test, _ = load_split()
L = Logger("neural", "cnn1d_ae")
for k in [4, 8, 16]:
    print(f"Training 1D-CNN-AE k={k}")
    m = train_model(CNN1DAE(k=k), train.reshape(-1, 200), epochs=EPOCHS)
    r, rec = evaluate(m, test)
    L.log("1D-CNN-AE", f"k={k}", r, rec if k == 4 else None)
