import numpy as np
import torch
import torch.nn as nn
from common.metrics import quantize, score


# ---------- per-pixel models (Model 1 MLP, Model 2 1D-CNN) ----------

def train_model(model, X, epochs=400, batch=256, lr=2e-3, log_every=100):
    """X: (num_pixels, bands) training spectra."""
    X = torch.tensor(X)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    loss_fn = nn.MSELoss()
    model.train()
    for ep in range(epochs):
        perm = torch.randperm(len(X))
        total = 0.0
        for i in range(0, len(X), batch):
            xb = X[perm[i:i + batch]]
            loss = loss_fn(model(xb), xb)
            opt.zero_grad(); loss.backward(); opt.step()
            total += loss.item() * len(xb)
        sched.step()
        if log_every and (ep % log_every == 0 or ep == epochs - 1):
            print(f"  epoch {ep:4d}  train MSE {total / len(X):.6f}", flush=True)
    return model


@torch.no_grad()
def evaluate(model, test, bits=8):
    """test: (H, W, bands) cube. Returns (metrics dict, reconstruction)."""
    model.eval()
    z = model.encode(torch.tensor(test.reshape(-1, test.shape[-1])))
    zq, nbits = quantize(z, bits, ch_dim=-1)
    rec = model.decode(zq).numpy().reshape(test.shape)
    return score(test, rec, nbits), rec


# ---------- patch model (Model 3 3D-CNN) ----------

def to_vol(cube):
    """(H, W, B) numpy -> (1, 1, B, H, W) tensor."""
    return torch.tensor(cube).permute(2, 0, 1)[None, None]


def train_patch_model(model, train, steps=1500, batch=4, patch=24, lr=2e-3,
                      log_every=250):
    """Trains on random spatial crops of the TRAIN region."""
    H, W, _ = train.shape
    vol = to_vol(train)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, steps)
    loss_fn = nn.MSELoss()
    model.train()
    for step in range(steps):
        ys = np.random.randint(0, H - patch + 1, batch)
        xs = np.random.randint(0, W - patch + 1, batch)
        xb = torch.cat([vol[..., y:y + patch, x:x + patch] for y, x in zip(ys, xs)])
        loss = loss_fn(model(xb), xb)
        opt.zero_grad(); loss.backward(); opt.step(); sched.step()
        if log_every and (step % log_every == 0 or step == steps - 1):
            print(f"  step {step:5d}  train MSE {loss.item():.6f}", flush=True)
    return model


@torch.no_grad()
def evaluate_patch(model, test, bits=8, mult=4):
    """Whole test region in one pass (padded to a multiple of `mult`).
    Bits are counted on the padded code, so padding overhead is included."""
    model.eval()
    H, W, _ = test.shape
    ph, pw = (-H) % mult, (-W) % mult
    padded = np.pad(test, ((0, ph), (0, pw), (0, 0)), mode="reflect")
    z = model.encode(to_vol(padded))
    zq, nbits = quantize(z, bits, ch_dim=1)
    rec = model.decode(zq)[0, 0].permute(1, 2, 0).numpy()[:H, :W]
    return score(test, rec, nbits), rec
